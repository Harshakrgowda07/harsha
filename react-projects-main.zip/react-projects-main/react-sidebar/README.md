# React Sidebar

<p align="center">
  <img src="https://github.com/opendevs-org/react-projects/raw/main/react-sidebar/public/preview.png" width="15%" title="Preview" alt="Preview">
</p>

# Contributed by

<table>
  <tbody>
    <tr>
      <td align="center"><a href="https://www.linkedin.com/in/ankit-kanyal-43460b169"><img src="https://avatars.githubusercontent.com/u/35369589?v=3?s=100" width="100px;" alt=""/><br /><sub><b>Ankit Kanyal</b></sub></a><br /></td>
    </tr>
  </tbody>
</table>
